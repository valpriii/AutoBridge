package com.dev.autobridge.data.repository

import com.dev.autobridge.domain.firebase.CHILD_CHATS
import com.dev.autobridge.domain.firebase.DB
import com.dev.autobridge.domain.firebase.NODE_CHATS
import com.dev.autobridge.domain.firebase.NODE_USERS
import com.dev.autobridge.domain.firebase.getDataOnce
import com.dev.autobridge.domain.firebase.getStringVal
import com.dev.autobridge.domain.model.Chat
import com.dev.autobridge.domain.util.Result
import com.google.android.play.integrity.internal.f
import javax.xml.xpath.XPathConstants.NODE

object ChatRepository {
    suspend fun createChat(chatId: String, uid1: String, uid2: String): String? {
        val chatSnapshot = DB.child(NODE_CHATS).child(chatId).getDataOnce()
        if (chatSnapshot.exists()) return chatId

        val user1 = when (val res = UserRepository.loadUser(uid1)) {
            is Result.Success -> res.data
            is Result.Error -> return null
        }
        val user2 = when (val res = UserRepository.loadUser(uid2)) {
            is Result.Success -> res.data
            is Result.Error -> return null
        }
        val chat = Chat(chatId, user1, user2, "")
        DB.child(NODE_CHATS).child(chat.id).setValue(chat.getAsMap())

        var user1Chats = DB.child(NODE_USERS).child(user1.id).child(CHILD_CHATS).getStringVal()
        var user2Chats = DB.child(NODE_USERS).child(user2.id).child(CHILD_CHATS).getStringVal()

        if (user1Chats.isEmpty()) user1Chats = chat.id else user1Chats += ",${chat.id}"
        if (user2Chats.isEmpty()) user2Chats = chat.id else user2Chats += ",${chat.id}"

        DB.child(NODE_USERS).child(user1.id).child(CHILD_CHATS).setValue(user1Chats)
        DB.child(NODE_USERS).child(user2.id).child(CHILD_CHATS).setValue(user2Chats)

        return chat.id
    }
}