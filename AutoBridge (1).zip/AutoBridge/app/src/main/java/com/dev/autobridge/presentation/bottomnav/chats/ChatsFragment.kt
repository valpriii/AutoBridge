package com.dev.autobridge.presentation.bottomnav.chats

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.dev.autobridge.databinding.ChatItemBinding
import com.dev.autobridge.databinding.FragmentChatsBinding
import com.dev.autobridge.domain.firebase.AUTH
import com.dev.autobridge.presentation.activity.ChatActivity
import com.dev.autobridge.presentation.bottomnav.chats.viewmodel.ChatsFragmentViewModel
import com.dev.autobridge.presentation.recyclerview.RvAdapter
import kotlinx.coroutines.launch

class ChatsFragment : Fragment() {

    private lateinit var binding: FragmentChatsBinding
    private val viewModel: ChatsFragmentViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentChatsBinding.inflate(inflater, container, false)

        loadChats()

        return binding.root
    }

    private fun loadChats() = lifecycleScope.launch {
        AUTH.currentUser?.uid?.let { uid ->
            viewModel.loadChats(uid).collect { chats ->
                binding.rvChats.layoutManager = LinearLayoutManager(requireContext())
                binding.rvChats.adapter = RvAdapter (
                    items = chats.reversed(),
                    holderBinder =  { binding, chat, _ ->
                        if (uid == chat.user1.id) {
                            binding.tvChatUser.text = chat.user2.name
                            if (chat.user2.profileImageUrl.isNotEmpty())
                                Glide.with(requireContext()).load(chat.user2.profileImageUrl).into(binding.ivServiceOwner)
                        }
                        else {
                            binding.tvChatUser.text = chat.user1.name

                            if (chat.user1.profileImageUrl.isNotEmpty())
                                Glide.with(requireContext()).load(chat.user1.profileImageUrl).into(binding.ivServiceOwner)
                        }

                        binding.tvLastMsg.text = chat.lastMsg
                        binding.root.setOnClickListener {
                            val intent = Intent(context, ChatActivity::class.java)
                            intent.putExtra("chatId", chat.id)
                            startActivity(intent)
                        }
                    },
                    bindingInflater = { layoutInflater, viewGroup, b ->
                        ChatItemBinding.inflate(layoutInflater, viewGroup, b)
                    }
                )
            }
        }
    }
}