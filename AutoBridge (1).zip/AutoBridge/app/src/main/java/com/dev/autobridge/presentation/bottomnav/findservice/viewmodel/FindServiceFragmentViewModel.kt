package com.dev.autobridge.presentation.bottomnav.findservice.viewmodel

import android.app.Service
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dev.autobridge.data.repository.ChatRepository
import com.dev.autobridge.data.repository.ServiceRepository
import com.dev.autobridge.data.repository.UserRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch

class FindServiceFragmentViewModel : ViewModel() {
    fun loadServices(query: String) = flow {
        if (query.isEmpty()) {
            emit(emptyList())
            return@flow
        }
        val services = ServiceRepository.loadServices(query)
        emit(services)
    }

    fun createChat(uid1: String, uid2: String, onFinished: (String?) -> Unit) = viewModelScope.launch {
        val symbols = (uid1.toCharArray() + uid2.toCharArray())
        symbols.sort()
        val chatId = symbols.concatToString()
        val res = ChatRepository.createChat(chatId, uid1, uid2)

        onFinished(res)
    }
}