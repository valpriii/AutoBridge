package com.dev.autobridge.domain.model

import com.dev.autobridge.domain.firebase.CHILD_BIO
import com.dev.autobridge.domain.firebase.CHILD_EMAIL
import com.dev.autobridge.domain.firebase.CHILD_EXPERIENCE
import com.dev.autobridge.domain.firebase.CHILD_NAME
import com.dev.autobridge.domain.firebase.CHILD_PROFILE_IMAGE
import com.dev.autobridge.domain.firebase.CHILD_RATING

data class User(
    var id: String = "",
    val name: String = "",
    val email: String = "",
    var profileImageUrl: String = "",
    val experience: Int? = null,
    val bio: String = "",
    val rating: Double? = null
) {
    fun getAsMap() = mapOf(
        CHILD_NAME to name,
        CHILD_EMAIL to email,
        CHILD_PROFILE_IMAGE to profileImageUrl,
        CHILD_EXPERIENCE to experience,
        CHILD_BIO to bio,
        CHILD_RATING to rating
    )
}
