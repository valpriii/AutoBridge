package com.dev.autobridge.presentation.bottomnav.profile

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.dev.autobridge.R
import com.dev.autobridge.databinding.FragmentProfileBinding
import com.dev.autobridge.domain.firebase.AUTH
import com.dev.autobridge.domain.util.Result
import com.dev.autobridge.presentation.activity.LoginActivity
import com.dev.autobridge.presentation.bottomnav.profile.viewmodel.ProfileFragmentViewModel
import com.dev.autobridge.presentation.bottomsheet.AddServiceBottomSheet
import kotlinx.coroutines.launch

class ProfileFragment : Fragment() {

    private lateinit var binding: FragmentProfileBinding
    private val viewModel: ProfileFragmentViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentProfileBinding.inflate(inflater, container, false)

        loadProfile()

        binding.tabReviews.setOnClickListener {
            (childFragmentManager.findFragmentById(R.id.profile_tabs_fragment) as? NavHostFragment)?.navController?.let {  navController ->
                navController.navigate(R.id.tab_reviews)
                binding.tabReviews.setBackgroundResource(R.drawable.grey_background_shape)
                binding.tabServices.setBackgroundResource(R.drawable.transparent_bg)
            }
        }

        binding.tabServices.setOnClickListener {
            (childFragmentManager.findFragmentById(R.id.profile_tabs_fragment) as? NavHostFragment)?.navController?.let {  navController ->
                navController.navigate(R.id.tab_services)
                binding.tabServices.setBackgroundResource(R.drawable.grey_background_shape)
                binding.tabReviews.setBackgroundResource(R.drawable.transparent_bg)
            }
        }

        binding.btnAddService.setOnClickListener {
            val addServiceBottomSheet = AddServiceBottomSheet(
                onServiceAdded = {
                    activity?.runOnUiThread {
                        (childFragmentManager.findFragmentById(R.id.profile_tabs_fragment) as? NavHostFragment)?.navController?.let { navController ->
                            navController.navigate(R.id.tab_services)
                            binding.tabServices.setBackgroundResource(R.drawable.grey_background_shape)
                            binding.tabReviews.setBackgroundResource(R.drawable.transparent_bg)
                        }
                    }
                }
            )
            addServiceBottomSheet.show(parentFragmentManager, null)
        }

        binding.btnLogout.setOnClickListener {
            AUTH.signOut()
            startActivity(Intent(requireContext(), LoginActivity::class.java))
            activity?.finish()
        }

        return binding.root
    }

    private fun loadProfile() = AUTH.currentUser?.uid?.let { uid ->
        lifecycleScope.launch {
            viewModel.loadUser(uid).collect { res ->
                when (res) {
                    is Result.Success -> {
                        binding.tvName.text = res.data.name
                        binding.tvEmail.text = res.data.email
                        res.data.rating?.let {
                            binding.tvRating.text = it.toString()
                        }
                        if (res.data.profileImageUrl.isNotEmpty())
                            Glide.with(requireContext()).load(res.data.profileImageUrl).into(binding.ivProfileImage)
                    }
                    is Result.Error -> {
                        Toast.makeText(requireContext(), res.msg, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}