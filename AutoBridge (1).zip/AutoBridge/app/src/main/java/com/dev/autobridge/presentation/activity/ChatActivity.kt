package com.dev.autobridge.presentation.activity

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.dev.autobridge.R
import com.dev.autobridge.databinding.ActivityChatBinding
import com.dev.autobridge.databinding.RateDialogBinding
import com.dev.autobridge.domain.firebase.AUTH
import com.dev.autobridge.domain.model.Message
import com.dev.autobridge.domain.model.Review
import com.dev.autobridge.presentation.activity.viewmodel.ChatActivityViewModel
import com.dev.autobridge.presentation.bottomsheet.AddReviewBottomSheet
import com.dev.autobridge.presentation.recyclerview.MessagesAdapter
import com.dev.autobridge.presentation.util.InsetsWithKeyboardCallback
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Calendar

class ChatActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChatBinding
    private val viewModel: ChatActivityViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.enableEdgeToEdge()
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v: View, insets: WindowInsetsCompat ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        setInsets()

        binding.sendMessageBtn.setOnClickListener {
            val messageText = binding.messageEt.text.toString()
            if (messageText.isEmpty()) {
                Toast.makeText(this, "Введите сообщение", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            binding.messageEt.setText("")
            intent?.getStringExtra("chatId")?.let { chatId ->
                val sentAt = System.currentTimeMillis()
                val message = Message (
                    sentAt.toString(),
                    messageText,
                    AUTH.currentUser?.uid ?: "",
                    registrationTime = 0,
                    sentAt = sentAt
                )
                viewModel.sendMessage(chatId, message)
            }
        }

        binding.btnSendRegistration.setOnClickListener {
            openDateTimePickerAndGetMillis(this) { millis ->
                intent?.getStringExtra("chatId")?.let { chatId ->
                    val sentAt = System.currentTimeMillis()
                    val message = Message (
                        sentAt.toString(),
                        "Предлагаю вам запись на ${SimpleDateFormat("dd.MM.yyyy HH:mm").format(millis)}",
                        AUTH.currentUser?.uid ?: "",
                        registrationTime = millis,
                        sentAt = sentAt
                    )
                    viewModel.sendMessage(chatId, message)
                }
            }
        }

        binding.btnAddReview.setOnClickListener {
            val bs = AddReviewBottomSheet {  text, rating ->
                intent?.getStringExtra("chatId")?.let { chatId ->
                    val sentAt = System.currentTimeMillis()
                    val review = Review(
                        sentAt.toString(),
                        text,
                        rating,
                        null,
                        sentAt
                    )
                    viewModel.rate(AUTH.currentUser?.uid?:"", review, chatId)
                }
            }
            bs.show(supportFragmentManager, null)
        }
    }

    private fun setInsets() {
        val insetsWithKeyboardCallback = InsetsWithKeyboardCallback(window)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main, insetsWithKeyboardCallback)
        ViewCompat.setWindowInsetsAnimationCallback(binding.main, insetsWithKeyboardCallback)
    }

    override fun onResume() {
        loadMessages()
        super.onResume()
    }

    override fun onStop() {
        intent?.getStringExtra("chatId")?.let {
            viewModel.stopListening(it)
        }
        super.onStop()
    }

    private fun openDateTimePickerAndGetMillis(context: Context, onDateTimeSet: (Long) -> Unit) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val hour = calendar.get(Calendar.HOUR_OF_DAY)
                val minute = calendar.get(Calendar.MINUTE)

                val timePickerDialog = TimePickerDialog(
                    context,
                    { _, hourOfDay, minute ->
                        calendar.set(year, month, dayOfMonth, hourOfDay, minute)
                        onDateTimeSet(calendar.timeInMillis)
                    },
                    hour,
                    minute,
                    true // Use 24-hour format
                )
                timePickerDialog.show()
            },
            year,
            month,
            day
        )
        datePickerDialog.show()
    }
    private fun loadMessages() = intent?.getStringExtra("chatId")?.let { chatId ->
        viewModel.startListening(chatId)
        viewModel.messages.observe(this) { messages ->
            AUTH.currentUser?.uid?.let { uid ->
                binding.rvChats.layoutManager = LinearLayoutManager(this)
                binding.rvChats.adapter = MessagesAdapter(messages, uid)
            }
        }
    }
}