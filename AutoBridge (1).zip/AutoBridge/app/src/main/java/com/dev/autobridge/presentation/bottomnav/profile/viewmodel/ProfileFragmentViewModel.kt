package com.dev.autobridge.presentation.bottomnav.profile.viewmodel

import androidx.lifecycle.ViewModel
import com.dev.autobridge.data.repository.UserRepository
import kotlinx.coroutines.flow.flow

class ProfileFragmentViewModel : ViewModel() {
    fun loadUser(uid: String) = flow {
        emit(UserRepository.loadUser(uid))
    }
}