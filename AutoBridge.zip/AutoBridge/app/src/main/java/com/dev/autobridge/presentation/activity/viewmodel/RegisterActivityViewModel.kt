package com.dev.autobridge.presentation.activity.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import com.dev.autobridge.data.repository.UserRepository
import com.dev.autobridge.domain.model.User
import com.dev.autobridge.domain.util.Result

class RegisterActivityViewModel : ViewModel() {
    var profileImageUri: Uri? = null

    fun register(user: User, password: String, onFinished: (Result<Unit>) -> Unit) {
        UserRepository.register(user, password, profileImageUri, onFinished)
    }
}