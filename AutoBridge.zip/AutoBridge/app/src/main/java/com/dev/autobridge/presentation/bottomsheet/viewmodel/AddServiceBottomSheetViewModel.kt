package com.dev.autobridge.presentation.bottomsheet.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dev.autobridge.data.repository.UserRepository
import com.dev.autobridge.domain.model.Service
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AddServiceBottomSheetViewModel : ViewModel() {
    fun addService(uid: String, service: Service, onFinished: () -> Unit) = viewModelScope.launch(Dispatchers.IO) {
        UserRepository.addService(uid, service, onFinished)
    }
    fun updateService(service: Service, onFinished: () -> Unit) = viewModelScope.launch(Dispatchers.IO) {
        UserRepository.updateService(service, onFinished)
    }
}