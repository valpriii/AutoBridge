package com.dev.autobridge.domain.model

import com.dev.autobridge.domain.firebase.CHILD_ADDRESS
import com.dev.autobridge.domain.firebase.CHILD_OWNER_ID
import com.dev.autobridge.domain.firebase.CHILD_PRICE
import com.dev.autobridge.domain.firebase.CHILD_TITLE

data class Service(
    val id: String,
    var title: String,
    var price: Int,
    val owner: User,
    var address: String
) {
    fun getAsMap() = mapOf(
        CHILD_TITLE to title,
        CHILD_PRICE to price,
        CHILD_OWNER_ID to owner.id,
        CHILD_ADDRESS to address
    )
}
