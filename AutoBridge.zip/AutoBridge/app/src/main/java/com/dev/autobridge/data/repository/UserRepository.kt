package com.dev.autobridge.data.repository

import android.net.Uri
import com.dev.autobridge.domain.firebase.AUTH
import com.dev.autobridge.domain.firebase.CHILD_BIO
import com.dev.autobridge.domain.firebase.CHILD_CHATS
import com.dev.autobridge.domain.firebase.CHILD_EMAIL
import com.dev.autobridge.domain.firebase.CHILD_EXPERIENCE
import com.dev.autobridge.domain.firebase.CHILD_LAST_MSG
import com.dev.autobridge.domain.firebase.CHILD_NAME
import com.dev.autobridge.domain.firebase.CHILD_OWNER_ID
import com.dev.autobridge.domain.firebase.CHILD_PRICE
import com.dev.autobridge.domain.firebase.CHILD_PROFILE_IMAGE
import com.dev.autobridge.domain.firebase.CHILD_RATING
import com.dev.autobridge.domain.firebase.CHILD_REVIEWS
import com.dev.autobridge.domain.firebase.CHILD_SERVICES
import com.dev.autobridge.domain.firebase.CHILD_TEXT
import com.dev.autobridge.domain.firebase.CHILD_TITLE
import com.dev.autobridge.domain.firebase.CHILD_USERID1
import com.dev.autobridge.domain.firebase.CHILD_USERID2
import com.dev.autobridge.domain.firebase.DB
import com.dev.autobridge.domain.firebase.NODE_CHATS
import com.dev.autobridge.domain.firebase.NODE_REVIEWS
import com.dev.autobridge.domain.firebase.NODE_SERVICES
import com.dev.autobridge.domain.firebase.NODE_USERS
import com.dev.autobridge.domain.firebase.STORAGE
import com.dev.autobridge.domain.firebase.getDataOnce
import com.dev.autobridge.domain.firebase.getStringVal
import com.dev.autobridge.domain.model.Chat
import com.dev.autobridge.domain.model.Review
import com.dev.autobridge.domain.model.Service
import com.dev.autobridge.domain.model.User
import com.dev.autobridge.domain.util.Result
import com.google.android.play.integrity.internal.al
import com.google.android.play.integrity.internal.i
import java.util.UUID

object UserRepository {
    fun register(user: User, password: String, profileImageUri: Uri? = null, onFinished: (Result<Unit>) -> Unit) {
        AUTH.createUserWithEmailAndPassword(user.email, password)
            .addOnCompleteListener {
                if (it.isSuccessful) {
                    it.result.user?.uid?.let { uid ->
                        user.id = uid
                        profileImageUri?.let { imageUri ->
                            uploadProfileImage(imageUri, uid) { uploadTask ->
                                when (uploadTask) {
                                    is Result.Success -> {
                                        user.profileImageUrl = uploadTask.data
                                        addUserToDb(user, onFinished)
                                    }
                                    is Result.Error -> onFinished(Result.Error(uploadTask.msg))
                                }
                            }
                        } ?: run {
                            addUserToDb(user, onFinished)
                        }
                    } ?: run { onFinished(Result.Error("Ошибка получения id пользователя"))}
                } else onFinished(Result.Error("Ошибка регистраци пользователя в системе. ${it.exception?.message}"))
            }
    }

    private fun addUserToDb(user: User, onFinished: (Result<Unit>) -> Unit) {
        DB.child(NODE_USERS).child(user.id).setValue(user.getAsMap())
            .addOnCompleteListener {
                if (it.isSuccessful) onFinished(Result.Success(Unit))
                else onFinished(Result.Error("Ошибка добавления пользователя в базу данных. ${it.exception?.message}"))
            }
    }

    fun uploadProfileImage(uri: Uri, uid: String, onFinished: (Result<String>) -> Unit) {
        STORAGE.child(uid).putFile(uri).addOnCompleteListener { uploadTask ->
            if (uploadTask.isSuccessful) {
                STORAGE.child(uid).downloadUrl.addOnCompleteListener { urlTask ->
                    if (urlTask.isSuccessful) {
                        onFinished(Result.Success(urlTask.result.toString()))
                    } else onFinished(Result.Error("Ошибка получения ссылки на фото профиля"))
                }
            } else onFinished(Result.Error("Ошибка загрузки фото профиля в хранилище"))
        }
    }

    suspend fun loadUser(uid: String): Result<User> {
        val snapshot = DB.child(NODE_USERS).child(uid).getDataOnce()
        if (!snapshot.exists()) return Result.Error("Ошибка: пользователя не существует")

        val id = snapshot.key.toString()
        val name = snapshot.child(CHILD_NAME).value.toString()
        val email = snapshot.child(CHILD_EMAIL).value.toString()
        val profileImageUrl = snapshot.child(CHILD_PROFILE_IMAGE).value.toString()
        val experience = if (snapshot.child(CHILD_EXPERIENCE).value.toString().matches(Regex("^-?\\d+$")))
            snapshot.child(CHILD_EXPERIENCE).value.toString().toInt() else null
        val bio = snapshot.child(CHILD_BIO).value.toString()
        val rating = if (snapshot.child(CHILD_RATING).value.toString().matches(Regex("^-?\\d+(\\.\\d+)?([eE][-+]?\\d+)?$")))
            snapshot.child(CHILD_RATING).value.toString().toDouble() else null

        return Result.Success(User(id, name, email, profileImageUrl, experience, bio, rating))
    }

    suspend fun loadUserReviews(uid: String): Result<List<Review>> {
        val snapshot = DB.child(NODE_USERS).child(uid).child(CHILD_REVIEWS).getDataOnce()
        if (!snapshot.exists()) return Result.Success(emptyList())

        val reviewsStr = snapshot.value.toString()
        val reviewsArr = reviewsStr.split(",")
        val reviews = mutableListOf<Review>()

        val rSnapshot = DB.child(NODE_REVIEWS).getDataOnce()
        if (!rSnapshot.exists()) return Result.Success(emptyList())
        reviewsArr.forEach {
            val id = rSnapshot.child(it).child(CHILD_TEXT).value.toString()
            val text = rSnapshot.child(it).child(CHILD_TEXT).value.toString()
            val rating = rSnapshot.child(it).child(CHILD_RATING).value.toString().toInt()
            val ownerId = rSnapshot.child(it).child(CHILD_OWNER_ID).value.toString()
            val owner = when (val res = loadUser(ownerId)) {
                is Result.Success -> res.data
                is Result.Error -> null
            }

            reviews.add(Review(id,  text, rating, owner, System.currentTimeMillis()))
        }
        return Result.Success(reviews)
    }

    suspend fun loadUserServices(uid: String): Result<List<Service>> {
        val snapshot = DB.child(NODE_USERS).child(uid).child(CHILD_SERVICES).getDataOnce()
        if (!snapshot.exists()) return Result.Success(emptyList())

        val servicesStr = snapshot.value.toString()
        val servicesArr = servicesStr.split(",")
        val services = mutableListOf<Service>()

        val sSnapshot = DB.child(NODE_SERVICES).getDataOnce()
        if (!sSnapshot.exists()) return Result.Success(emptyList())
        servicesArr.forEach {
            val title = sSnapshot.child(it).child(CHILD_TITLE).value.toString()
            val price = sSnapshot.child(it).child(CHILD_PRICE).value.toString().toInt()
            val ownerId = sSnapshot.child(it).child(CHILD_OWNER_ID).value.toString()
            val owner = when (val res = loadUser(ownerId)) {
                is Result.Success -> res.data
                is Result.Error -> null
            }
            if (owner != null)
                services.add(Service(it, title, price, owner))
        }
        return Result.Success(services)
    }

    suspend fun addService(uid: String, service: Service, onFinished: () -> Unit) {
        val snapshot = DB.child(NODE_USERS).child(uid).child(CHILD_SERVICES).getDataOnce()

        val servicesStr = if (!snapshot.exists()) service.id else {
            if (snapshot.value.toString().isEmpty()) service.id
            else snapshot.value.toString() + "," + service.id
        }
        DB.child(NODE_USERS).child(uid).child(CHILD_SERVICES).setValue(servicesStr)
        DB.child(NODE_SERVICES).child(service.id).setValue(service.getAsMap())
        onFinished()
    }

    fun updateService(service: Service, onFinished: () -> Unit) {
        DB.child(NODE_SERVICES).child(service.id).setValue(service.getAsMap())
            .addOnCompleteListener { onFinished() }
    }

    suspend fun removeService(service: Service) {
        val snapshot = DB.child(NODE_USERS).child(service.owner.id).child(CHILD_SERVICES).getDataOnce()
        if (!snapshot.exists()) return

        val servicesStr = snapshot.value.toString()
        val servicesArr = servicesStr.split(",")
        val newServicesArr = servicesArr.filter { it != service.id }
        DB.child(NODE_USERS).child(service.owner.id).child(CHILD_SERVICES).setValue(newServicesArr.joinToString(","))
        DB.child(NODE_SERVICES).child(service.id).removeValue()
    }

    suspend fun loadUserChats(uid: String): List<Chat> {
        val snapshot = DB.child(NODE_USERS).child(uid).child(CHILD_CHATS).getDataOnce()
        if (!snapshot.exists()) return emptyList()

        val chatsStr = snapshot.value.toString()
        val chatsArr = chatsStr.split(",")
        val chats = mutableListOf<Chat>()
        val cSnapshot = DB.child(NODE_CHATS).getDataOnce()
        if (!cSnapshot.exists()) return emptyList()

        chatsArr.forEach {
            val userId1 = cSnapshot.child(it).child(CHILD_USERID1).value.toString()
            val userId2 = cSnapshot.child(it).child(CHILD_USERID2).value.toString()
            val lastMsg = cSnapshot.child(it).child(CHILD_LAST_MSG).value.toString()

            val user1 = when (val res = loadUser(userId1)) {
                is Result.Success -> res.data
                is Result.Error -> null
            }
            val user2 = when (val res = loadUser(userId2)) {
                is Result.Success -> res.data
                is Result.Error -> null
            }
            if (user1 != null && user2 != null) {
                chats.add(Chat(it, user1, user2, lastMsg))
            }
        }
        return chats
    }

    suspend fun addReview(uid: String, review: Review) {
        val userRatingStr = DB.child(NODE_USERS).child(uid).child(CHILD_RATING).getStringVal()
        var userRating = 0.0
        if (userRatingStr.isNotEmpty())
            userRating = userRatingStr.toDouble()

        val newRating = if (userRating == 0.0) userRating else (userRating + review.rating) / 2
        DB.child(NODE_USERS).child(uid).child(CHILD_RATING).setValue(newRating)

        DB.child(NODE_REVIEWS).child(review.id).setValue(review.getAsMap())
        val userReviewsStr = DB.child(NODE_USERS).child(uid).child(CHILD_REVIEWS).getStringVal()
        val newReviewsStr = if (userReviewsStr.isEmpty()) review.id else userReviewsStr + "," + review.id
        DB.child(NODE_USERS).child(uid).child(CHILD_REVIEWS).setValue(newReviewsStr)
    }
}