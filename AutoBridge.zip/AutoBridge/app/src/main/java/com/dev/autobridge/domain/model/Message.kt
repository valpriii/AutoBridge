package com.dev.autobridge.domain.model

import com.dev.autobridge.domain.firebase.CHILD_REGISTRATION_TIME
import com.dev.autobridge.domain.firebase.CHILD_SENDER
import com.dev.autobridge.domain.firebase.CHILD_SENT_AT
import com.dev.autobridge.domain.firebase.CHILD_TEXT

data class Message(
    val id: String,
    val text: String,
    val senderId: String,
    val registrationTime: Long = 0, // если мастер назначает запись
    val sentAt: Long
) {
    fun getAsMap() = mapOf(
        CHILD_TEXT to text,
        CHILD_SENDER to senderId,
        CHILD_REGISTRATION_TIME to registrationTime,
        CHILD_SENT_AT to sentAt
    )
}
