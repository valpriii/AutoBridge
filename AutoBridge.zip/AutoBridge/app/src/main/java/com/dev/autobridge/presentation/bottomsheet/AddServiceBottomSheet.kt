package com.dev.autobridge.presentation.bottomsheet

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import com.dev.autobridge.databinding.AddServiceBottomSheetBinding
import com.dev.autobridge.domain.firebase.AUTH
import com.dev.autobridge.domain.model.Service
import com.dev.autobridge.domain.model.User
import com.dev.autobridge.presentation.bottomsheet.viewmodel.AddServiceBottomSheetViewModel
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class AddServiceBottomSheet(
    private val onServiceAdded: (Service) -> Unit,
    private val service: Service? = null
) : BottomSheetDialogFragment() {

    private lateinit var binding: AddServiceBottomSheetBinding
    private val viewModel: AddServiceBottomSheetViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = AddServiceBottomSheetBinding.inflate(inflater, container, false)

        service?.let {
            binding.etServiceDesc.setText(it.title)
            binding.etServicePrice.setText(it.price.toString())
        }

        binding.btnAddService.setOnClickListener {
            val serviceTitle = binding.etServiceDesc.text.toString()
            val servicePrice = binding.etServicePrice.text.toString()
            val serviceAddress = binding.etServiceAddress.text.toString()

            if (serviceTitle.isEmpty() || servicePrice.isEmpty() || serviceAddress.isEmpty()) {
                Toast.makeText(requireContext(), "Пожалуйста, заполните все поля", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!servicePrice.matches(Regex("""-?\d+"""))) {
                Toast.makeText(requireContext(), "Поле 'Цена' должно содержать только цифры", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (servicePrice.toInt() < 0) {
                Toast.makeText(requireContext(), "Поле 'Цена' должно быть положительным числом", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            service?.let {
                it.title = serviceTitle
                it.price = servicePrice.toInt()
                it.address = serviceAddress
                viewModel.updateService(it) {
                    onServiceAdded(it)
                    dismiss()
                }
            } ?: run {
                AUTH.currentUser?.uid?.let { uid ->
                    val service = Service(System.currentTimeMillis().toString(), serviceTitle, servicePrice.toInt(), User(id = uid), serviceAddress)
                    viewModel.addService(uid, service) {
                        onServiceAdded(service)
                        dismiss()
                    }
                }
            }
        }

        return binding.root
    }
}