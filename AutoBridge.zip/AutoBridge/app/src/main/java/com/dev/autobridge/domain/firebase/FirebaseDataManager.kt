package com.dev.autobridge.domain.firebase

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

suspend fun DatabaseReference.getDataOnce(): DataSnapshot {
    return suspendCancellableCoroutine {
        this.addListenerForSingleValueEvent(object: ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                it.resume(snapshot)
            }

            override fun onCancelled(error: DatabaseError) {
                it.resumeWithException(error.toException())
            }
        })
    }
}

suspend fun DatabaseReference.getStringVal(): String {
    return suspendCancellableCoroutine {
        this.addListenerForSingleValueEvent(object: ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) it.resume(snapshot.value.toString())
                else it.resume("")
            }

            override fun onCancelled(error: DatabaseError) {
                it.resumeWithException(error.toException())
            }
        })
    }
}