package com.dev.autobridge.presentation.bottomsheet

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.dev.autobridge.databinding.RateDialogBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.play.integrity.internal.c

class AddReviewBottomSheet(
    private val onRate: (String, Int) -> Unit
) : BottomSheetDialogFragment() {

    private lateinit var binding: RateDialogBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = RateDialogBinding.inflate(inflater, container, false)

        binding.btnRate.setOnClickListener {
            val review = binding.etReviewText.text.toString()
            val rating = binding.etRating.text.toString()
            if (!rating.matches(Regex("^[1-5]$"))) {
                Toast.makeText(context, "Введите оценку от 1 до 5", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (review.isEmpty()) {
                Toast.makeText(context, "Введите отзыв", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            onRate(review, rating.toInt())
            dismiss()
        }


        return binding.root
    }
}