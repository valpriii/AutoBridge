package com.dev.autobridge.presentation.bottomnav.profile.tabs.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dev.autobridge.data.repository.UserRepository
import com.dev.autobridge.domain.model.Service
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch

class UserServiceTabViewModel : ViewModel() {
    fun loadServices(uid: String) = flow {
        emit(UserRepository.loadUserServices(uid))
    }

    fun removeService(service: Service) = viewModelScope.launch(Dispatchers.IO) {
        UserRepository.removeService(service)
    }
}