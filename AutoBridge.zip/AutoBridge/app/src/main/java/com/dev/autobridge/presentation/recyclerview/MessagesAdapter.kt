package com.dev.autobridge.presentation.recyclerview

import android.content.ContentUris
import android.content.Intent
import android.provider.CalendarContract
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dev.autobridge.R
import com.dev.autobridge.domain.model.Message
import com.dev.autobridge.presentation.util.MessageBindingContainer
import java.text.SimpleDateFormat

class MessagesAdapter(
    private val messages: List<Message>,
    private val currUserId: String?
) : RecyclerView.Adapter<MessagesAdapter.MessageViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        return MessageViewHolder(
            if (viewType == R.layout.message_from_curr_user_rv_item)
                MessageBindingContainer.FromCurrUser(LayoutInflater.from(parent.context), parent, false)
            else
                MessageBindingContainer.FromChatUser(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        holder.bind(messages[position])
    }

    override fun getItemCount(): Int {
        return messages.size
    }

    override fun getItemViewType(position: Int): Int {
        // определяем от кого отправлено сообщение
        return if (messages[position].senderId == currUserId) R.layout.message_from_curr_user_rv_item else R.layout.message_rv_item
    }

    inner class MessageViewHolder(private val binding: MessageBindingContainer) : RecyclerView.ViewHolder(binding.root) {
        fun bind(message: Message) {
            when (binding) {
                is MessageBindingContainer.FromCurrUser -> {
                    val mBinding = binding.binding
                    mBinding.messageTv.text = message.text
                    mBinding.messageDateTv.text = SimpleDateFormat("dd.MM.yyyy HH:mm").format(message.sentAt)

                    if (message.registrationTime != 0L) {
                        mBinding.btnRegister.setOnClickListener {
                            val builder = CalendarContract.CONTENT_URI.buildUpon().appendPath("time")
                            ContentUris.appendId(builder, message.registrationTime)
                            val intent = Intent(Intent.ACTION_VIEW).setData(builder.build())
                            binding.root.context.startActivity(intent)
                        }
                    } else mBinding.btnRegister.visibility = View.GONE
                }
                is MessageBindingContainer.FromChatUser -> {
                    val mBinding = binding.binding

                    mBinding.messageTv.text = message.text
                    mBinding.messageDateTv.text = SimpleDateFormat("dd.MM.yyyy HH:mm").format(message.sentAt)

                    if (message.registrationTime != 0L) {
                        mBinding.btnRegister.setOnClickListener {
                            val builder = CalendarContract.CONTENT_URI.buildUpon().appendPath("time")
                            ContentUris.appendId(builder, message.registrationTime)
                            val intent = Intent(Intent.ACTION_VIEW).setData(builder.build())
                            binding.root.context.startActivity(intent)
                        }
                    } else mBinding.btnRegister.visibility = View.GONE
                }
            }
        }
    }
}
