package com.dev.autobridge.presentation.bottomnav.findservice

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import android.widget.Toast
import androidx.appcompat.widget.SearchView.OnQueryTextListener
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.dev.autobridge.data.repository.ServiceRepository.loadServices
import com.dev.autobridge.databinding.FragmentFindServiceBinding
import com.dev.autobridge.databinding.ServiceItemBinding
import com.dev.autobridge.domain.firebase.AUTH
import com.dev.autobridge.presentation.activity.ChatActivity
import com.dev.autobridge.presentation.bottomnav.findservice.viewmodel.FindServiceFragmentViewModel
import com.dev.autobridge.presentation.recyclerview.RvAdapter
import kotlinx.coroutines.launch

class FindServiceFragment : Fragment() {

    private lateinit var binding: FragmentFindServiceBinding
    private val viewModel: FindServiceFragmentViewModel by viewModels()
    private lateinit var adapter: RvAdapter<com.dev.autobridge.domain.model.Service, ServiceItemBinding>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentFindServiceBinding.inflate(inflater, container, false)

        adapter = RvAdapter(
            items = emptyList(),
            holderBinder = { binding, service, adapter ->
                binding.tvServicePrice.text = "${service.price} руб."
                binding.tvServiceTitle.text = service.title
                binding.tvServiceOwner.text = service.owner.name
                binding.tvServiceOwnerRating.text = if (service.owner.rating == null) "0.0" else service.owner.rating.toString()

                binding.llActions.visibility = View.GONE
                if (service.owner.profileImageUrl.isNotEmpty())
                    Glide.with(requireContext()).load(service.owner.profileImageUrl).into(binding.ivServiceOwner)

                binding.btnChat.setOnClickListener {
                    AUTH.currentUser?.uid?.let { currUid ->
                        viewModel.createChat(currUid, service.owner.id) { chatId ->
                            chatId?.let {
                                val intent = Intent(context, ChatActivity::class.java)
                                intent.putExtra("chatId", it)
                                startActivity(intent)
                            } ?: run {
                                activity?.runOnUiThread {
                                    Toast.makeText(requireContext(), "Возникла ошибка при создании чата", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                }
            },
            bindingInflater = { layoutInflater, parent, attachToParent ->
                ServiceItemBinding.inflate(layoutInflater, parent, attachToParent)
            }
        )
        binding.rvServices.layoutManager = LinearLayoutManager(requireContext())
        binding.rvServices.adapter = adapter

        binding.searchService.setOnQueryTextListener(object: SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                query?.let {
                    loadServices(it)
                }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                newText?.let {
                    loadServices(it)
                }
                return true
            }
        })

        return binding.root
    }

    private fun loadServices(query: String) = lifecycleScope.launch {
        viewModel.loadServices(query).collect { services ->
            adapter.submitList(services)
        }
    }
}