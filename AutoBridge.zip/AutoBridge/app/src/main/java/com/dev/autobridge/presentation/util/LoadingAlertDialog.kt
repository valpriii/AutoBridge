package com.dev.autobridge.presentation.util

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import com.dev.autobridge.databinding.LoadingAlertDialogBinding

class LoadingAlertDialog(context: Context, private val message: String = "Загрузка...") : Dialog(context) {

    private lateinit var binding: LoadingAlertDialogBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = LoadingAlertDialogBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.loadingMsgTv.text = message
    }
}