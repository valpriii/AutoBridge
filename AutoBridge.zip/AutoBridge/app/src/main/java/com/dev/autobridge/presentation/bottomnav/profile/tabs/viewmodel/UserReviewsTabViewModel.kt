package com.dev.autobridge.presentation.bottomnav.profile.tabs.viewmodel

import androidx.lifecycle.ViewModel
import com.dev.autobridge.data.repository.UserRepository
import kotlinx.coroutines.flow.flow

class UserReviewsTabViewModel : ViewModel() {
    fun loadReviews(uid: String) = flow {
        emit(UserRepository.loadUserReviews(uid))
    }
}