package com.dev.autobridge.data.repository

import com.dev.autobridge.domain.firebase.DB
import com.dev.autobridge.domain.firebase.NODE_REGISTRATIONS
import com.dev.autobridge.domain.firebase.getDataOnce

object RegistrationRepository {
    suspend fun checkRegistration(uid1: String, uid2: String): Boolean {
        val registrationId = (uid1+uid2).toCharArray()
        registrationId.sort()
        val registrationIdString = registrationId.concatToString()
        val registrationSnapshot = DB.child(NODE_REGISTRATIONS).child(registrationIdString).getDataOnce()
        return registrationSnapshot.exists()
    }
    fun createRegistration(uid1: String, uid2: String) {
        val registrationId = (uid1+uid2).toCharArray()
        registrationId.sort()
        val registrationIdString = registrationId.concatToString()
        DB.child(NODE_REGISTRATIONS).child(registrationIdString).setValue(true)
    }
}