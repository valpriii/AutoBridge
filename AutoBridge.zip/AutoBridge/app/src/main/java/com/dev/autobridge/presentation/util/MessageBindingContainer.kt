package com.dev.autobridge.presentation.util

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.viewbinding.ViewBinding
import com.dev.autobridge.databinding.MessageFromCurrUserRvItemBinding
import com.dev.autobridge.databinding.MessageRvItemBinding

sealed class MessageBindingContainer : ViewBinding {
    abstract val binding: ViewBinding

    class FromCurrUser(
        layoutInflater: LayoutInflater,
        parent: ViewGroup,
        attachToParent: Boolean
    ) : MessageBindingContainer() {
        override val binding: MessageFromCurrUserRvItemBinding =
            MessageFromCurrUserRvItemBinding.inflate(layoutInflater, parent, attachToParent)

        override fun getRoot(): View = binding.root
    }

    class FromChatUser(
        layoutInflater: LayoutInflater,
        parent: ViewGroup,
        attachToParent: Boolean
    ) : MessageBindingContainer() {
        override val binding: MessageRvItemBinding =
            MessageRvItemBinding.inflate(layoutInflater, parent, attachToParent)

        override fun getRoot(): View = binding.root
    }
}