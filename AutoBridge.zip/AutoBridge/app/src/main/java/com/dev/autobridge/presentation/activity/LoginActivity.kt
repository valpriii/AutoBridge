package com.dev.autobridge.presentation.activity

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.dev.autobridge.R
import com.dev.autobridge.databinding.ActivityLoginBinding
import com.dev.autobridge.domain.firebase.AUTH
import com.dev.autobridge.domain.util.Result
import com.dev.autobridge.presentation.activity.viewmodel.LoginActivityViewModel

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val viewModel: LoginActivityViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        checkAuth()

        binding.tvToRegister.setOnClickListener { startActivity(Intent(this, RegisterActivity::class.java)) }

        binding.btnLogin.setOnClickListener {
            val email = binding.etEmail.text.toString()
            val password = binding.etPassword.text.toString()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this@LoginActivity, "Пожалуйста, заполните все поля для ввода", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            viewModel.login(email, password) { res ->
                when (res) {
                    is Result.Success -> {
                        Toast.makeText(this@LoginActivity, "Успешно совершен вход в аккаунт", Toast.LENGTH_SHORT).show()
                    }
                    is Result.Error -> {
                        Toast.makeText(this@LoginActivity, res.msg, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun checkAuth() {
        if (AUTH.currentUser != null) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}