package com.dev.autobridge.presentation.bottomnav.profile.tabs

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.dev.autobridge.databinding.FragmentProfileTabBinding
import com.dev.autobridge.databinding.ReviewItemBinding
import com.dev.autobridge.databinding.ServiceItemBinding
import com.dev.autobridge.domain.firebase.AUTH
import com.dev.autobridge.domain.util.Result
import com.dev.autobridge.presentation.bottomnav.profile.tabs.viewmodel.UserServiceTabViewModel
import com.dev.autobridge.presentation.bottomsheet.AddServiceBottomSheet
import com.dev.autobridge.presentation.recyclerview.RvAdapter
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat

class UserServicesTab : Fragment() {

    private lateinit var binding: FragmentProfileTabBinding
    private val viewModel: UserServiceTabViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentProfileTabBinding.inflate(inflater, container, false)

        AUTH.currentUser?.uid?.let { uid ->
            lifecycleScope.launch {
                viewModel.loadServices(uid).collect { res ->
                    when (res) {
                        is Result.Success -> {
                            val adapter = RvAdapter (
                                items = res.data.reversed(),
                                holderBinder = { binding, service, adapter ->
                                    binding.tvServicePrice.text = "${service.price} руб."
                                    binding.tvServiceTitle.text = service.title

                                    if (uid == service.owner.id) binding.llServiceOwner.visibility = View.GONE

                                    binding.btnEdit.setOnClickListener {
                                        val addServiceBottomSheet = AddServiceBottomSheet({
                                            val servicesUpd = res.data.toMutableList()
                                            servicesUpd.replaceAll {
                                                if (it.id == service.id) service.copy() else it
                                            }
                                            adapter.submitList(servicesUpd)
                                        }, service)
                                        addServiceBottomSheet.show(childFragmentManager, "UpdateServiceBottomSheet")
                                    }
                                    binding.btnDelete.setOnClickListener {
                                        viewModel.removeService(service)
                                        val services = res.data.toMutableList()
                                        services.remove(service)
                                        adapter.submitList(services)
                                    }
                                },
                                bindingInflater = { layoutInflater, parent, attachToParent ->
                                    ServiceItemBinding.inflate(layoutInflater, parent, attachToParent)
                                }
                            )
                            binding.rvUserServices.layoutManager = LinearLayoutManager(context)
                            binding.rvUserServices.adapter = adapter
                        }
                        is Result.Error -> {
                            Toast.makeText(requireContext(), res.msg, Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }

        return binding.root
    }
}