package com.dev.autobridge.presentation.bottomnav.chats.viewmodel

import androidx.lifecycle.ViewModel
import com.dev.autobridge.data.repository.UserRepository
import kotlinx.coroutines.flow.flow

class ChatsFragmentViewModel : ViewModel() {
    fun loadChats(uid: String) = flow {
        emit(UserRepository.loadUserChats(uid))
    }
}