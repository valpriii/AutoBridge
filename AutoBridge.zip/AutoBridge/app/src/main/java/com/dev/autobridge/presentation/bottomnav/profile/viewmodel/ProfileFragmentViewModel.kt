package com.dev.autobridge.presentation.bottomnav.profile.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import com.dev.autobridge.data.repository.UserRepository
import com.dev.autobridge.domain.util.Result
import kotlinx.coroutines.flow.flow

class ProfileFragmentViewModel : ViewModel() {
    fun loadUser(uid: String) = flow {
        emit(UserRepository.loadUser(uid))
    }

    fun uploadProfileImage(imageUri: Uri, uid: String,  onFinished: (Result<Unit>) -> Unit) {
        UserRepository.uploadProfileImage(imageUri, uid) {
            when (it) {
                is Result.Success -> {
                    UserRepository.updateProfileImageUrl(uid, it.data, onFinished)
                }

                is Result.Error -> onFinished(Result.Error(it.msg))
            }
        }
    }

    fun updateUsername(uid: String, username: String, onFinished: (Result<Unit>) -> Unit) {
        UserRepository.updateUsername(uid, username, onFinished)
    }
}