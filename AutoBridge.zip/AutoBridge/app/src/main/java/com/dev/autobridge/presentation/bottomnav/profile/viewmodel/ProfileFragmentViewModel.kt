package com.dev.autobridge.presentation.bottomnav.profile.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dev.autobridge.data.repository.ChatRepository
import com.dev.autobridge.data.repository.UserRepository
import com.dev.autobridge.domain.util.Result
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch

class ProfileFragmentViewModel : ViewModel() {
    fun loadUser(uid: String) = flow {
        emit(UserRepository.loadUser(uid))
    }

    fun uploadProfileImage(imageUri: Uri, uid: String,  onFinished: (Result<Unit>) -> Unit) {
        UserRepository.uploadProfileImage(imageUri, uid) {
            when (it) {
                is Result.Success -> {
                    UserRepository.updateProfileImageUrl(uid, it.data, onFinished)
                }

                is Result.Error -> onFinished(Result.Error(it.msg))
            }
        }
    }

    fun updateUsername(uid: String, username: String, onFinished: (Result<Unit>) -> Unit) {
        UserRepository.updateUsername(uid, username, onFinished)
    }

    fun createChat(uid1: String, uid2: String, onFinished: (String?) -> Unit) = viewModelScope.launch {
        val symbols = (uid1.toCharArray() + uid2.toCharArray())
        symbols.sort()
        val chatId = symbols.concatToString()
        val res = ChatRepository.createChat(chatId, uid1, uid2)

        onFinished(res)
    }
}