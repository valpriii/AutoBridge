package com.dev.autobridge.presentation.activity

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.dev.autobridge.R
import com.dev.autobridge.databinding.ActivityRegisterBinding
import com.dev.autobridge.domain.model.User
import com.dev.autobridge.domain.util.Result
import com.dev.autobridge.presentation.activity.viewmodel.RegisterActivityViewModel
import com.dev.autobridge.presentation.util.LoadingAlertDialog

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private val viewModel: RegisterActivityViewModel by viewModels()
    private lateinit var loadingAlertDialog: LoadingAlertDialog

    private val imagePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            binding.ivProfileImage.setImageURI(it)
            viewModel.profileImageUri = it
        } ?: run {
            Toast.makeText(this, "Ошибка выбора фотографии", Toast.LENGTH_SHORT).show()
        }
    }

    private val imagePermissionRequestLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            imagePickerLauncher.launch("image/*")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        loadingAlertDialog = LoadingAlertDialog(this)

        binding.ivProfileImage.setOnClickListener {
            var permission = Manifest.permission.READ_EXTERNAL_STORAGE
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                permission = Manifest.permission.READ_MEDIA_IMAGES

            if (ContextCompat.checkSelfPermission(this@RegisterActivity, permission) != PackageManager.PERMISSION_GRANTED) {
                imagePermissionRequestLauncher.launch(permission)
            } else imagePickerLauncher.launch("image/*")
        }

        binding.btnRegister.setOnClickListener {
            val name = binding.etName.text.toString()
            val email = binding.etEmail.text.toString()
            val password = binding.etPassword.text.toString()

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this@RegisterActivity, "Пожалуйста, заполните все поля", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            loadingAlertDialog.show()
            val user = User(
                name = name,
                email = email
            )
            viewModel.register(user, password) { res ->
                when (res) {
                    is Result.Success -> {
                        Toast.makeText(this@RegisterActivity, "Поздравляем с успешной регистрацией!", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this@RegisterActivity, MainActivity::class.java))
                        finish()
                    }
                    is Result.Error -> {
                        Toast.makeText(this@RegisterActivity, res.msg, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}