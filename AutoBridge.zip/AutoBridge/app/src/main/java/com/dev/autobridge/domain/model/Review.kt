package com.dev.autobridge.domain.model

import com.dev.autobridge.domain.firebase.CHILD_CREATED_AT
import com.dev.autobridge.domain.firebase.CHILD_OWNER_ID
import com.dev.autobridge.domain.firebase.CHILD_RATING
import com.dev.autobridge.domain.firebase.CHILD_TEXT

data class Review(
    val id: String,
    val text: String,
    val rating: Int,
    var owner: User?,
    val createdAt: Long
) {
    fun getAsMap() = mapOf(
        CHILD_TEXT to text,
        CHILD_RATING to rating,
        CHILD_OWNER_ID to owner?.id,
        CHILD_CREATED_AT to createdAt
    )
}
