package com.dev.autobridge.presentation.activity.viewmodel

import androidx.lifecycle.ViewModel
import com.dev.autobridge.domain.firebase.AUTH
import com.dev.autobridge.domain.util.Result

class LoginActivityViewModel : ViewModel() {
    fun login(email: String, password: String, onFinished: (Result<Unit>) -> Unit) {
        AUTH.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener {
                if (it.isSuccessful) onFinished(Result.Success(Unit))
                else onFinished(Result.Error("Ошибка входа в аккаунт. ${it.exception?.message}"))
            }
    }
}