package com.dev.autobridge.presentation.bottomnav.profile

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.dev.autobridge.R
import com.dev.autobridge.databinding.FragmentProfileBinding
import com.dev.autobridge.domain.firebase.AUTH
import com.dev.autobridge.domain.util.Result
import com.dev.autobridge.presentation.activity.LoginActivity
import com.dev.autobridge.presentation.bottomnav.profile.viewmodel.ProfileFragmentViewModel
import com.dev.autobridge.presentation.bottomsheet.AddServiceBottomSheet
import com.dev.autobridge.presentation.bottomsheet.EditUsernameBottomSheet
import com.dev.autobridge.presentation.bottomsheet.QualificationDetailsBottomSheet
import kotlinx.coroutines.launch

class ProfileFragment : Fragment() {

    private lateinit var binding: FragmentProfileBinding
    private val viewModel: ProfileFragmentViewModel by viewModels()
    private val args: ProfileFragmentArgs by navArgs()
    private lateinit var uid: String

    private val galleryPickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            binding.ivProfileImage.setImageURI(uri)

            AUTH.currentUser?.uid?.let { uid ->
                viewModel.uploadProfileImage(uri, uid) { res ->
                    when (res) {
                        is Result.Success -> {
                            Toast.makeText(requireContext(), "Фотография профиля успешно загружено", Toast.LENGTH_SHORT).show()
                        }
                        is Result.Error -> Toast.makeText(requireContext(), res.msg, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private val permissionRequestLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            galleryPickerLauncher.launch("image/*")
        } else
            Toast.makeText(requireContext(), "Необходимо разрешение на доступ к галерее", Toast.LENGTH_SHORT).show()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentProfileBinding.inflate(inflater, container, false)

        uid = args.userId
        if (uid.isNotEmpty()) {
            binding.btnLogout.visibility = View.GONE
            binding.btnProfileEdit.visibility = View.GONE
            binding.btnProfileEdit.visibility = View.GONE
            binding.btnAddService.visibility = View.GONE

        } else {
            setUpOnClick()
        }

        loadProfile()

        binding.tabReviews.setOnClickListener {
            (childFragmentManager.findFragmentById(R.id.profile_tabs_fragment) as? NavHostFragment)?.navController?.let {  navController ->
                navController.navigate(R.id.tab_reviews)
                binding.tabReviews.setBackgroundResource(R.drawable.grey_background_shape)
                binding.tabServices.setBackgroundResource(R.drawable.transparent_bg)
            }
        }

        binding.tabServices.setOnClickListener {
            (childFragmentManager.findFragmentById(R.id.profile_tabs_fragment) as? NavHostFragment)?.navController?.let {  navController ->
                navController.navigate(R.id.tab_services)
                binding.tabServices.setBackgroundResource(R.drawable.grey_background_shape)
                binding.tabReviews.setBackgroundResource(R.drawable.transparent_bg)
            }
        }

        binding.ivProfileImage.setOnClickListener {
            var permission = Manifest.permission.READ_EXTERNAL_STORAGE
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                permission = Manifest.permission.READ_MEDIA_IMAGES
            if (ContextCompat.checkSelfPermission(requireContext(), permission) != PackageManager.PERMISSION_GRANTED) {
                permissionRequestLauncher.launch(permission)
            } else {
                galleryPickerLauncher.launch("image/*")
            }
        }

        binding.btnQualificationDetails.setOnClickListener {
            val qualificationDetailsBottomSheet = QualificationDetailsBottomSheet(uid)
            qualificationDetailsBottomSheet.show(parentFragmentManager, "qualification-details-bottom-sheet")
        }

        return binding.root
    }

    private fun setUpOnClick() {
        binding.btnLogout.setOnClickListener {
            AUTH.signOut()
            startActivity(Intent(requireContext(), LoginActivity::class.java))
            activity?.finish()
        }
        binding.btnAddService.setOnClickListener {
            val addServiceBottomSheet = AddServiceBottomSheet(
                onServiceAdded = {
                    activity?.runOnUiThread {
                        (childFragmentManager.findFragmentById(R.id.profile_tabs_fragment) as? NavHostFragment)?.navController?.let { navController ->
                            navController.navigate(R.id.tab_services)
                            binding.tabServices.setBackgroundResource(R.drawable.grey_background_shape)
                            binding.tabReviews.setBackgroundResource(R.drawable.transparent_bg)
                        }
                    }
                }
            )
            addServiceBottomSheet.show(parentFragmentManager, null)
        }
        binding.btnProfileEdit.setOnClickListener {
            val editUsernameBottomSheet = EditUsernameBottomSheet(binding.tvName.text.toString()) { updName ->
                AUTH.currentUser?.uid?.let { uid ->
                    binding.tvName.text = updName
                    viewModel.updateUsername(uid, updName) { res ->
                        when (res) {
                            is Result.Success -> Toast.makeText(requireContext(), "Имя пользователя успешно обновлено", Toast.LENGTH_SHORT).show()
                            is Result.Error -> Toast.makeText(requireContext(), res.msg, Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            editUsernameBottomSheet.show(parentFragmentManager, null)
        }
    }

    private fun loadProfile() {
        lifecycleScope.launch {
            if (uid.isNotEmpty()) {
                viewModel.loadUser(uid).collect { res ->
                    when (res) {
                        is Result.Success -> {
                            binding.tvName.text = res.data.name
                            binding.tvEmail.text = res.data.email
                            res.data.rating?.let {
                                binding.tvRating.text = it.toString()
                            }
                            if (res.data.profileImageUrl.isNotEmpty())
                                Glide.with(requireContext()).load(res.data.profileImageUrl).into(binding.ivProfileImage)
                        }
                        is Result.Error -> {
                            Toast.makeText(requireContext(), res.msg, Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            } else {
                AUTH.currentUser?.uid?.let {
                    viewModel.loadUser(it).collect { res ->
                        when (res) {
                            is Result.Success -> {
                                binding.tvName.text = res.data.name
                                binding.tvEmail.text = res.data.email
                                res.data.rating?.let {
                                    binding.tvRating.text = it.toString()
                                }
                                if (res.data.profileImageUrl.isNotEmpty())
                                    Glide.with(requireContext()).load(res.data.profileImageUrl).into(binding.ivProfileImage)
                            }
                            is Result.Error -> {
                                Toast.makeText(requireContext(), res.msg, Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            }
        }
    }
}