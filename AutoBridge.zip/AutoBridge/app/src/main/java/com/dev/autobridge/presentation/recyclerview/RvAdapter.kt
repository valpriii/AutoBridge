package com.dev.autobridge.presentation.recyclerview

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import androidx.viewbinding.ViewBinding

class RvAdapter<E, VB: ViewBinding> (
    private val items: List<E>,
    private val holderBinder: (VB, E, RvAdapter<E, VB>) -> Unit,
    private val bindingInflater: (LayoutInflater, ViewGroup?, Boolean) -> VB,
    private val filter: (E) -> Boolean = { true }
) : RecyclerView.Adapter<RvAdapter<E, VB>.ViewHolder>() {

    private val itemCallback = object: DiffUtil.ItemCallback<E>() {
        override fun areItemsTheSame(oldItem: E & Any, newItem: E & Any): Boolean = (oldItem === newItem)

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: E & Any, newItem: E & Any): Boolean = (oldItem == newItem)
    }
    private val differ = AsyncListDiffer(this, itemCallback)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = bindingInflater(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = differ.currentList.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(differ.currentList[position])
    }

    inner class ViewHolder(private val binding: VB): RecyclerView.ViewHolder(binding.root) {
        fun bind(value: E) {
            holderBinder(binding, value, this@RvAdapter)
        }
    }

    fun submitList(newList: List<E>) {
        differ.submitList(newList)
    }

    fun getCurrList() = differ.currentList

    init {
        differ.submitList(items)
    }
}