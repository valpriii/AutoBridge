package com.dev.autobridge.domain.firebase

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage

val AUTH = FirebaseAuth.getInstance()
val DB = FirebaseDatabase.getInstance().reference
val STORAGE = FirebaseStorage.getInstance().reference