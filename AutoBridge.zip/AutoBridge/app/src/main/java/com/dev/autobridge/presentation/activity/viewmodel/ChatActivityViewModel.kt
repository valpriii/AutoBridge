package com.dev.autobridge.presentation.activity.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dev.autobridge.data.repository.UserRepository
import com.dev.autobridge.data.repository.UserRepository.loadUser
import com.dev.autobridge.domain.firebase.CHILD_LAST_MSG
import com.dev.autobridge.domain.firebase.CHILD_MESSAGES
import com.dev.autobridge.domain.firebase.CHILD_REGISTRATION_TIME
import com.dev.autobridge.domain.firebase.CHILD_SENDER
import com.dev.autobridge.domain.firebase.CHILD_SENT_AT
import com.dev.autobridge.domain.firebase.CHILD_TEXT
import com.dev.autobridge.domain.firebase.CHILD_USERID1
import com.dev.autobridge.domain.firebase.CHILD_USERID2
import com.dev.autobridge.domain.firebase.DB
import com.dev.autobridge.domain.firebase.NODE_CHATS
import com.dev.autobridge.domain.firebase.getStringVal
import com.dev.autobridge.domain.model.Message
import com.dev.autobridge.domain.model.Review
import com.dev.autobridge.domain.model.User
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ChatActivityViewModel : ViewModel() {
    val messages = MutableLiveData<List<Message>>()
    private var listener: ValueEventListener? = null

    fun rate(curUid: String, review: Review, chatId: String) = viewModelScope.launch(Dispatchers.IO) {
        val userId1 = DB.child(NODE_CHATS).child(chatId).child(CHILD_USERID1).getStringVal()
        val userId2 = DB.child(NODE_CHATS).child(chatId).child(CHILD_USERID2).getStringVal()

        if (userId1 == curUid) {
            review.owner = User(id = userId1)
            UserRepository.addReview(userId2, review)
        } else {
            review.owner = User(id = userId2)
            UserRepository.addReview(userId1, review)
        }
    }

    fun startListening(chatId: String) {
        listener = object: ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) {
                    messages.postValue(emptyList())
                    return
                } else {
                    viewModelScope.launch(Dispatchers.IO) {
                        val messages = mutableListOf<Message>()
                        snapshot.children.forEach {
                            if (!it.exists()) return@forEach
                            val id = it.key.toString()
                            val senderId = it.child(CHILD_SENDER).value.toString()
                            val text = it.child(CHILD_TEXT).value.toString()
                            val sentAt = (it.child(CHILD_SENT_AT).value?:"0").toString().toLong()
                            val registrationTime = (it.child(CHILD_REGISTRATION_TIME).value?:-1).toString().toLong()

                            messages.add(Message(id, text, senderId, registrationTime, sentAt))
                        }
                        messages.sortBy {
                            it.sentAt
                        }
                        this@ChatActivityViewModel.messages.postValue(messages)
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {}
        }
        listener?.let {
            DB.child(NODE_CHATS).child(chatId).child(CHILD_MESSAGES).addValueEventListener(it)
        }
    }

    fun stopListening(chatId: String) {
        listener?.let {
            DB.child(NODE_CHATS).child(chatId).child(CHILD_MESSAGES).removeEventListener(it)
        }
    }

    fun sendMessage(chatId: String, message: Message) {
        DB.child(NODE_CHATS).child(chatId).child(CHILD_MESSAGES).child(message.id).setValue(message.getAsMap())
        DB.child(NODE_CHATS).child(chatId).child(CHILD_LAST_MSG).setValue(message.text)
    }
}