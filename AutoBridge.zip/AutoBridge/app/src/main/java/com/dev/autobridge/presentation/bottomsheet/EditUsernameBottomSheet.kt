package com.dev.autobridge.presentation.bottomsheet

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.dev.autobridge.databinding.EditUsernameBottomSheetBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class EditUsernameBottomSheet(
    private val currentName: String,
    private val onUserNameChanged: (String) -> Unit
): BottomSheetDialogFragment() {

    private lateinit var binding: EditUsernameBottomSheetBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = EditUsernameBottomSheetBinding.inflate(inflater, container, false)

        binding.etEditUsername.setText(currentName)
        binding.btnSave.setOnClickListener {
            val newUsername = binding.etEditUsername.text.toString()
            onUserNameChanged(newUsername)
            dismiss()
        }

        return binding.root
    }
}