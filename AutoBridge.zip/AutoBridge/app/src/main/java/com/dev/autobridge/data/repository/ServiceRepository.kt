package com.dev.autobridge.data.repository

import com.dev.autobridge.databinding.ServiceItemBinding
import com.dev.autobridge.domain.firebase.CHILD_ADDRESS
import com.dev.autobridge.domain.firebase.CHILD_OWNER_ID
import com.dev.autobridge.domain.firebase.CHILD_PRICE
import com.dev.autobridge.domain.firebase.CHILD_TITLE
import com.dev.autobridge.domain.firebase.DB
import com.dev.autobridge.domain.firebase.NODE_SERVICES
import com.dev.autobridge.domain.firebase.getDataOnce
import com.dev.autobridge.domain.model.Service
import com.dev.autobridge.domain.util.Result
import com.google.android.play.integrity.internal.i

object ServiceRepository {
    suspend fun loadServices(query: String): List<Service> {
        val snapshot = DB.child(NODE_SERVICES).getDataOnce()
        if (!snapshot.exists()) return emptyList()

        val services = mutableListOf<Service>()
        snapshot.children.forEach {
            val title = it.child(CHILD_TITLE).value.toString()
            if (!title.lowercase().contains(query.lowercase())) return@forEach
            val price = it.child(CHILD_PRICE).value.toString().toInt()
            val ownerId = it.child(CHILD_OWNER_ID).value.toString()
            val address = (it.child(CHILD_ADDRESS).value ?: "").toString()
            val owner = when (val res = UserRepository.loadUser(ownerId)) {
                is Result.Success -> res.data
                is Result.Error -> null
            }

            owner?.let { owner ->
                services.add(Service(it.key.toString(), title, price, owner, address))
            }
        }
        return services
    }
    suspend fun loadLatestServices(): List<Service> {
        val snapshot = DB.child(NODE_SERVICES).getDataOnce()
        if (!snapshot.exists()) return emptyList()

        val services = mutableListOf<Service>()
        snapshot.children.reversed().forEachIndexed { i, it ->
            if (i==9) return services

            val title = it.child(CHILD_TITLE).value.toString()
            val price = it.child(CHILD_PRICE).value.toString().toInt()
            val ownerId = it.child(CHILD_OWNER_ID).value.toString()
            val address = (it.child(CHILD_ADDRESS).value ?: "").toString()
            val owner = when (val res = UserRepository.loadUser(ownerId)) {
                is Result.Success -> res.data
                is Result.Error -> null
            }

            owner?.let { owner ->
                services.add(Service(it.key.toString(), title, price, owner, address))
            }
        }
        return services
    }
}