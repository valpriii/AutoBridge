package com.dev.autobridge.presentation.bottomsheet.viewmodel

import androidx.lifecycle.ViewModel
import com.dev.autobridge.data.repository.UserRepository
import com.dev.autobridge.domain.util.Result
import kotlinx.coroutines.flow.flow

typealias IsValid = Boolean

class QualificationDetailsBottomSheetViewModel : ViewModel() {
    fun loadUserInfo(uid: String) = flow {
        emit(UserRepository.loadUser(uid))
    }
    fun updateQualificationDetails(uid: String, bio: String, experience: Int, onFinished: (Result<Unit>) -> Unit) {
        UserRepository.updateQualificationInfo(uid, bio, experience, onFinished)
    }
    fun checkExperienceStr(experience: String): IsValid = experience.matches(Regex("""-?\d+"""))
}