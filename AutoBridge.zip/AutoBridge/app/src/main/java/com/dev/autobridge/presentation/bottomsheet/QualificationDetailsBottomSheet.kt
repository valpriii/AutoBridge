package com.dev.autobridge.presentation.bottomsheet

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import com.dev.autobridge.databinding.QualificationDetailsBottomSheetBinding
import com.dev.autobridge.domain.firebase.AUTH
import com.dev.autobridge.domain.model.User
import com.dev.autobridge.domain.util.Result
import com.dev.autobridge.presentation.bottomsheet.viewmodel.QualificationDetailsBottomSheetViewModel
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import kotlinx.coroutines.launch

class QualificationDetailsBottomSheet(
    private val uid: String
) : BottomSheetDialogFragment() {

    private lateinit var binding: QualificationDetailsBottomSheetBinding
    private val viewModel: QualificationDetailsBottomSheetViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = QualificationDetailsBottomSheetBinding.inflate(inflater, container, false)

        loadUser()

        if (uid.isNotEmpty()) {
            binding.btnSave.visibility = View.GONE
            binding.etBio.isEnabled = false
            binding.etExperience.isEnabled = false
        } else {
            binding.btnSave.setOnClickListener {
                val bio = binding.etBio.text.toString()
                val experience = binding.etExperience.text.toString()

                if (bio.isEmpty() || experience.isEmpty()) {
                    Toast.makeText(requireContext(), "Пожалуйста, заполните все поля", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (!viewModel.checkExperienceStr(experience)) {
                    Toast.makeText(requireContext(), "Ваш опыт должен быть целым числом", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                AUTH.currentUser?.uid?.let { uid ->
                    viewModel.updateQualificationDetails(uid, bio, experience.toInt()) {
                        when (it) {
                            is Result.Success -> {
                                Toast.makeText(requireContext(), "Данные успешно обновлены", Toast.LENGTH_SHORT).show()
                                dismiss()
                            }
                            is Result.Error -> {
                                Toast.makeText(requireContext(), it.msg, Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            }
        }

        return binding.root
    }

    private fun loadUser() {
        lifecycleScope.launch {
            if (uid.isNotEmpty()) {
                viewModel.loadUserInfo(uid).collect { res ->
                    when (res) {
                        is Result.Success -> {
                            binding.etBio.setText(res.data.bio)
                            binding.etExperience.setText(if (res.data.experience == null) "" else res.data.experience.toString())
                        }
                        is Result.Error -> {
                            Toast.makeText(requireContext(), res.msg, Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            } else {
                AUTH.currentUser?.uid?.let {
                    viewModel.loadUserInfo(it).collect { res ->
                        when (res) {
                            is Result.Success -> {
                                binding.etBio.setText(res.data.bio)
                                binding.etExperience.setText(if (res.data.experience == null) "" else res.data.experience.toString())
                            }

                            is Result.Error -> {
                                Toast.makeText(requireContext(), res.msg, Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            }
        }
    }
}