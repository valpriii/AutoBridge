package com.dev.autobridge.domain.model

import com.dev.autobridge.domain.firebase.CHILD_LAST_MSG
import com.dev.autobridge.domain.firebase.CHILD_USERID1
import com.dev.autobridge.domain.firebase.CHILD_USERID2

data class Chat(
    val id: String,
    val user1: User,
    val user2: User,
    val lastMsg: String
) {
    fun getAsMap() = mapOf(
        CHILD_USERID1 to user1.id,
        CHILD_USERID2 to user2.id,
        CHILD_LAST_MSG to lastMsg
    )
}
