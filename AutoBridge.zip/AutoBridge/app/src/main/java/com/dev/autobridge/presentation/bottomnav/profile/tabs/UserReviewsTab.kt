package com.dev.autobridge.presentation.bottomnav.profile.tabs

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.dev.autobridge.databinding.FragmentProfileTabBinding
import com.dev.autobridge.databinding.ReviewItemBinding
import com.dev.autobridge.domain.firebase.AUTH
import com.dev.autobridge.domain.model.Review
import com.dev.autobridge.domain.util.Result
import com.dev.autobridge.presentation.bottomnav.profile.tabs.viewmodel.UserReviewsTabViewModel
import com.dev.autobridge.presentation.recyclerview.RvAdapter
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat

class UserReviewsTab : Fragment() {

    private lateinit var binding: FragmentProfileTabBinding
    private val viewModel: UserReviewsTabViewModel by viewModels()
    private val args: UserReviewsTabArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentProfileTabBinding.inflate(inflater, container, false)

        lifecycleScope.launch {
            viewModel.loadReviews(args.uid).collect { res ->
                when (res) {
                    is Result.Success -> {
                        val adapter = RvAdapter (
                            items = res.data.reversed(),
                            holderBinder = { binding, review, _ ->
                                review.owner?.let {  owner ->
                                    binding.tvUsername.text = owner.name
                                    binding.tvDate.text = SimpleDateFormat("dd.MM.yyyy HH:mm").format(review.createdAt)

                                    if (owner.profileImageUrl.isNotEmpty())
                                        Glide.with(requireContext()).load(owner.profileImageUrl).into(binding.ivProfileImage)

                                    binding.tvRating.text = "Оценка: ${review.rating}"
                                }
                                binding.tvReview.text = review.text
                            },
                            bindingInflater = { layoutInflater, parent, attachToParent ->
                                ReviewItemBinding.inflate(layoutInflater, parent, attachToParent)
                            }
                        )
                        binding.rvUserServices.layoutManager = LinearLayoutManager(context)
                        binding.rvUserServices.adapter = adapter
                    }
                    is Result.Error -> {
                        Toast.makeText(requireContext(), res.msg, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        return binding.root
    }
}